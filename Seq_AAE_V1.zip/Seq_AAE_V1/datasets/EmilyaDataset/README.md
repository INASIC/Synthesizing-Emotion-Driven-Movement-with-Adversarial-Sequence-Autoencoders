### Data Preprocessing
For preprocessing Emylia dataset, you can navigate to the folder named './src' under current directory. There, you should first modify the data\_path in the 'dataset\_2\_npz.py' file to the path where you put the Emilya dataset. Then run 'python dataset\_2\_npz.py', which will save all the motions into a .npz file.

* This file was created by Qi Wang, not Anthony Hills
