"""
This code is adapted from Qi Wang's open source code on GitHub. This code
is used to train the overal style-free adversarial sequential autoencoder
which is used to generate emotion driven movement in this project.

Qi Wang's original code can be found here:
    https://github.com/lucaskingjade/Motion_Synthesis_Adversarial_Learning
"""

import sys
import os
root_path = os.getcwd()[:-45]  # Gets the path above the root directory, so we can more conveniently import functions from other directories
sys.path.append(root_path)
from Seq_AAE_V1.datasets.dataset import Emilya_Dataset
from Seq_AAE_V1.double_gan_conditional_saae import Double_GAN_Conditional_SAAE
import tensorflow as tf

tf.keras.backend.clear_session()  # Reset the model

# Pre-process the dataset
dataset_obj = Emilya_Dataset(
                            window_width=100,  # How many frames to truncate
                            number=100,  # Number of frames in training set
                            nb_valid=100,  # Number of frames in validation set
                            nb_test=100,  # Number of frames in test set
                            sampling_interval=None,  # Downsamples the window width (default=None=1 frame)
                            shift_step=20,  # Shift the beginning of the sequence shift_step frames into the future (i.e. How many frames in the future we begin the sequence.)
                            with_velocity=True  # Convert angles to velocities
                            )

# Define the model
model = Double_GAN_Conditional_SAAE(
                            # Parameters that effect how quickly the model trains
                            max_epoch=100+1,  # Specify the stopping point for how many training epochs are sufficient for the model to be fully learned
                            batch_size=20,  # How many samples model trains on before weight update (smaller = faster training)
                            lr_autoencoder=0.001, lr_dis=0.00005, lr_classifier=0.000025,  # Learning rate for autonencoder, adversarial discriminator, style classifier

                            train_disc=True, train_classifier=True,
                            checkpoint_epochs=100,  # Specify how frequently results are generated and the model saved, for each checkpoint

                            # Output dimensions for each layer (how many output neurons each layer has)
                            latent_dim=50,  # 1 layer (ideally should be less than initial input to compress to fewer dimensions)
                            hidden_dim_enc_list=[100],  # 1 layers in recurrent module of encoder
                            hidden_dim_dec_list=[100],  # 1 layer in recurrent module of decoder
                            hidden_dim_dis_list=[100, 50],  # 2 fully connected layers
                            hidden_dim_classifier_list=[100,50],  # 2 fully connected layers

                            # Activation functions for each layer
                            activation_enc_list=['tanh'],  # Encoder layers
                            activation_dec_list=['tanh'],  # Decoder
                            latent_activation='tanh',  # Encoding
                            activation_dis_list=['relu', 'relu'],  # Discriminator
                            activation_classifier_list=['relu','relu'],  # Classifier

                            # Overfitting - Hyperparameters to reduce it
                            dropout_dis_list=[0.0,0.0], dropout_classifier_list=[0.,0.],  # Dropout probabilities in layers of discriminator and classifier
                            decay_autoencoder=0.0, decay_dis=0.0, decay_classifier=0.0,  # Weight decay to avoid overfitting
                            momentum_autoencoder=0.0, momentum_dis=0.0,  # Momentum to avoid overfitting due to learning rate

                            # Optimization methods for modules of model
                            optimiser_autoencoder='rmsprop',
                            optimiser_dis='adam',  # sgd
                            optimiser_classifier='adam',

                            # Model architecture customization
                            forget_bias=True,  # Choose to add a forget gate to your LSTM/ GRU, to help avoid numerical instability
                            lstm_or_gru='lstm',  # Train encoder and decoder with either lstm/ gru modules
                            symetric_autoencoder=False,
                            custom_loss=True,  # Init
                            prior_noise_type='Gaussian',  # Noise samples which are used to constrain encodings
                            embedding_dim=0,
                            # leaky_relu_alpha=0.3,  # Amount of gradient permitted to ReLU to avoid zero gradient
                            # custom_loss=False,
                            # clip_norm=1.,  # Clips the weight gradients to a maximum norm of 1, to avoid exploding gradients via gradient clipping

                            # Generation
                            condition_activity_or_emotion=1,  # Generate conditioned on either 1 =  activity or 2 = emotion .
                            nb_to_generate=100,  # Specify number of sequences for each type to be generated, at each checkpoint epoch
                            nb_label=8,  # Specify number of style lables to be generated

                            # Regularizes the "loss_neg_entropy" optimization objective by multiplying it
                            bias_beta=10.,  # bias_beta=0.,  # Leads to good results
                            is_annealing_beta=False,
                            # beta_anneal_rate=0.1,

                            # Initializer
                            loss_weights=[1.0,0.001,0.0005],  # How heavily we weight each element of the loss function: (1) 'Decoder': self.loss_mse_velocity_loss, (2) 'Discmt': 'binary_crossentropy', (3) 'Classifier':self.loss_neg_entropy},
                            loss_weight_mse_v = 100.0,  # Was 1.0 before
                            latent_BN = False,  # Apply batch normalization to latent layer
                            fully_condition=True,  

                            # kernel weight_initializer
                            kernel_weight_initialization='he_uniform',  # He weight initialization, recommended for ReLU activations
                            bias_initialization = 0.1
                            )

# Train the defined model
model.training(dataset_obj)
