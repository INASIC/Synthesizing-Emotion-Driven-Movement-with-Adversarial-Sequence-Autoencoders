# Adversarial Learning for Modeling Human Motion

This repository contains the open source code which reproduces the results for the paper: [Adversarial learning for modeling human motion](https://link.springer.com/article/10.1007%2Fs00371-018-1594-7). The authors of this paper are: Qi Wang, Thierry Artières, Mickael Chen, and Ludovic Denoyer.

# How to Reproduce the Results

1) Download the EMILYA dataset. This can be achieved by contacting the owner [Catherine Pelachaud](http://pages.isir.upmc.fr/~pelachaud/).

2) Clone this repository code to your computer and ensure the root folder is still named "Seq_AAE_V1" .

4) Data Preprocessing: Save the motions in EmilyaDataset into a npz file by looking at the readme.md file in the folder 'datasets/EmilyaDaset/'.

5) For training the models in the paper, navigate to the "\Training" directory under the root directory of the project and there you can find the following folder: Double\_Gan\_Condition\_SAAE.

By running the training file in terminal, 'training_double_gan_conditional_saae_delta.py' you will be able to train the model from scratch. If you want to tune the hyperparameters, this can be done by modifying these in the training file. The full model script is contained at the root directory as 'double_gan_conditional_saae.py.

# Access to the Report

The LaTeX file that compiles the final report is contained in the root directory, in a zip file called "AnthonyHills_1876183_OyaCeliktutan_FinalReport_2018-19.zip".  
