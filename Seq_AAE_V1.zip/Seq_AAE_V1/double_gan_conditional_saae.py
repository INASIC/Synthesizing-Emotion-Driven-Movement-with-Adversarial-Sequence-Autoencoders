"""
This code is adapted from Qi Wang's open source code on GitHub. This code
is used to define the overal style-free adversarial sequential autoencoder
which is used to generate emotion driven movement in this project.

Qi Wang's original code can be found here:
    https://github.com/lucaskingjade/Motion_Synthesis_Adversarial_Learning
"""

import numpy as np
from keras.layers import Input,LSTM,RepeatVector,Dense,SimpleRNN,GRU,Embedding
from keras.models import Model
from keras.optimizers import Adam,RMSprop,SGD
from keras.layers import TimeDistributed,merge,BatchNormalization,Dropout, concatenate
from keras import initializers
#from prior_distribution import mixture_gaussian_sampling
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from Seq_AAE_V1.datasets.dataset import generate_positive_samples
from sklearn.base import BaseEstimator
import keras.backend as K
from keras.utils.vis_utils import plot_model
from Seq_AAE_V1.synthesis_scripts.synthesis_utils import save_seq_2_bvh
from matplotlib.colors import Colormap,LogNorm,PowerNorm
from keras.models import model_from_yaml
import tensorflow as tf

# from sklearn.preprocessing import StandardScaler
# from sklearn.preprocessing import MinMaxScaler
from keras.layers import LeakyReLU
from keras import callbacks


class Double_GAN_Conditional_SAAE(BaseEstimator):

    def __init__(self,
                forget_bias=True,  # Added this to improve stability and avoid vanishing gradient
                lstm_or_gru='lstm',  # Train encoder and decoder with either lstm/ gru modules
                clip_norm=None,  # Avoids vanishing/ exploding gradients via gradient clipping
                leaky_relu_alpha=None,
                kernel_weight_initialization=None,  # He weight initialization, recommended for ReLU activations
                bias_initialization = None,

                 latent_dim=50,latent_activation='tanh',latent_BN=False,
                 hidden_dim_enc_list=[100,100],activation_enc_list=['tanh','tanh'],
                 hidden_dim_dec_list=None,activation_dec_list=None,
                 hidden_dim_dis_list=[100,40],activation_dis_list=['relu','relu'],
                 hidden_dim_classifier_list=[100, 40], activation_classifier_list=['relu', 'relu'],
                 dropout_dis_list=[0.0,0.0],
                 dropout_classifier_list=[0.0, 0.0],
                 batch_size=200,max_epoch=200,
                 optimiser_autoencoder='rmsprop',optimiser_dis='sgd',
                 optimiser_classifier= 'sgd',
                 lr_autoencoder=0.001,lr_dis=0.01,
                 decay_autoencoder=0.0,decay_dis=0.0,
                 lr_classifier = 0.01,decay_classifier = 0.0,
                 momentum_autoencoder=0.0,momentum_dis=0.0,
                 momentum_classifier = 0.0,
                 prior_noise_type='Gaussian',
                 nb_mixture = 8,
                 loss_weights=[1.0,0.0,0.0],
                 train_disc=True,
                 train_classifier = True,
                 custom_loss=False,
                 loss_weight_mse_v= 1.0,
                 checkpoint_epochs=100,symetric_autoencoder=False,
                 nb_to_generate=10,
                 condition_activity_or_emotion=1,
                 nb_label=8,
                 fully_condition=True,dataset_obj=None,embedding_dim=0,
                 is_annealing_beta = False,
                 beta_anneal_rate=0.1,
                 bias_beta = 9.,
                 reload_model_path = None,
                 reload_checkpoint_epoch=0,):

        args = locals().copy()
        del args['self']
        self.__dict__.update(args)
        print args.keys()
        self.save_configuration(args)

    def set_up_model(self):

        # Load the model
        if self.reload_model_path is not None:
            self.iterations = self.reload_checkpoint_epoch * (len(self.train_X)/self.batch_size+1)
            if self.hidden_dim_dec_list is None:
                self.hidden_dim_dec_list = self.hidden_dim_enc_list[::-1]  # Get reverse of the hidden dim encoder list (so it's a symmetrical autoencoder)
            if self.activation_dec_list is None:
                self.activation_dec_list = self.activation_enc_list[::-1]

            self.alpha = K.variable(self.loss_weight_mse_v, name='alpha')
            if self.is_annealing_beta is True:
                self.beta_classifier = K.variable(0., name='beta_classifier')
            else:
                self.beta_classifier = K.variable(1., name='beta_classifier')

            #load all the models
            encoder_path = self.reload_model_path +'encoder'+str(self.reload_checkpoint_epoch)+'.yaml'
            # with open(encoder_path) as f:
            #     self.encoder = model_from_yaml(f)
            self.encoder = self.Encoder()
            self.encoder.load_weights(encoder_path[:-4]+'h5')

            decoder_path = self.reload_model_path + 'decoder' + str(self.reload_checkpoint_epoch) + '.yaml'
            # with open(decoder_path) as f:
            #     self.decoder = model_from_yaml(f)
            self.decoder = self.Decoder()
            self.decoder.load_weights(decoder_path[:-4]+'h5')

            discriminator_path = self.reload_model_path + 'discriminator' + str(self.reload_checkpoint_epoch) + '.yaml'
            # with open(discriminator_path) as f:
            #     self.discriminator = model_from_yaml(f)
            self.discriminator = self.Discriminator()
            self.discriminator.load_weights(discriminator_path[:-4]+'h5')

            classifier_path = self.reload_model_path + 'classifier' + str(self.reload_checkpoint_epoch) + '.yaml'
            # with open(classifier_path) as f:
            #     self.classifier = model_from_yaml(f)
            self.classifier = self.Classifier()
            self.classifier.load_weights(classifier_path[:-4] + 'h5')

            autoencoder_path = self.reload_model_path + 'autoencoder' + str(self.reload_checkpoint_epoch) + '.yaml'
            # with open(autoencoder_path) as f:
            #     self.autoencoder_with_discriminator = model_from_yaml(f)
            self.autoencoder_with_discriminator = self.Autoencoder_with_Discmt()
            self.autoencoder_with_discriminator.load_weights(autoencoder_path[:-4] + 'h5')
        else:
            self.iterations = 0
            if self.hidden_dim_dec_list is None:
                self.hidden_dim_dec_list = self.hidden_dim_enc_list[::-1]
            if self.activation_dec_list is None:
                self.activation_dec_list = self.activation_enc_list[::-1]

            self.alpha = K.variable(self.loss_weight_mse_v, name='alpha')
            if self.is_annealing_beta is True:
                self.beta_classifier = K.variable(0.,name='beta_classifier')
            else:
                self.beta_classifier = K.variable(1., name='beta_classifier')
            if self.symetric_autoencoder==True:
                self.encoder = self.Encoder_symetric()
            else:
                self.encoder = self.Encoder()
            self.decoder = self.Decoder()
            self.discriminator = self.Discriminator()
            self.classifier = self.Classifier()
            self.autoencoder_with_discriminator = self.Autoencoder_with_Discmt()

        self.compile()
        if self.reload_model_path is not None:
            K.set_value(self.autoencoder_with_discriminator.optimizer.iterations, self.iterations)
            K.set_value(self.discriminator.optimizer.iterations, self.iterations)
            K.set_value(self.classifier.optimizer.iterations, self.iterations)

        #summary of model
        self.visualize_model([self.encoder,self.decoder,self.discriminator,self.classifier,
                              self.autoencoder_with_discriminator])


    def visualize_model(self,models):
        for model in models:
            model.summary()
            plot_model(model,
                       to_file='%s.png' % model.name,
                       show_shapes=True,
                       show_layer_names=True)


    def save_configuration(self,arguments):
        with open('meta_data.txt','w') as file:
            file.writelines("========Meta Data========\r\n")
            for key in arguments.keys():
                file.writelines(key+' : '+ str(arguments[key])+'\r\n')
            file.writelines('===========END===========\r\n')


    def set_up_dataset(self,dataset_obj):
        #save datasource to meta_data.txt
        with open('meta_data.txt','a') as file:
            file.writelines(dataset_obj.file_source)

        if hasattr(dataset_obj,'max_len'):
            self.max_len = dataset_obj.max_len
        else:
            raise ValueError("Attribute 'max_len' doesn't exist in dataset obj ")

        if hasattr(dataset_obj,'dof'):
            self.dof = dataset_obj.dof-1
        else:
            raise ValueError("Attribute 'dof' doesn't exist in dataset obj ")

        self.train_X = dataset_obj.train_X[:,:,1:]
        self.train_Y1 = dataset_obj.train_Y1  # Activity labels
        self.train_Y2 = dataset_obj.train_Y2  # Emotion labels
        self.train_Y3 = dataset_obj.train_Y3  # Actor labels
        #self.train_speed = dataset_obj.train_speed

        self.valid_X = dataset_obj.valid_X[:,:,1:]
        self.valid_Y1 = dataset_obj.valid_Y1
        self.valid_Y2 = dataset_obj.valid_Y2
        self.valid_Y3 = dataset_obj.valid_Y3
        #self.valid_speed = dataset_obj.valid_speed

        self.test_X = dataset_obj.test_X[:,:,1:]
        self.test_Y1 = dataset_obj.test_Y1
        self.test_Y2 = dataset_obj.test_Y2
        self.test_Y3 = dataset_obj.test_Y3

        # Generate either conditioned on activity (1) or emotion (2)
        if self.condition_activity_or_emotion==1:  # activity
            self.train_label_one_hot_code = self.convert_indices_2_onehot(targets=self.train_Y1,nb_labels=self.nb_label)
            self.valid_label_one_hot_code = self.convert_indices_2_onehot(targets=self.valid_Y1,nb_labels=self.nb_label)
            self.test_label_one_hot_code = self.convert_indices_2_onehot(targets=self.test_Y1,nb_labels=self.nb_label)
        elif self.condition_activity_or_emotion==2:  # emotion
            self.train_label_one_hot_code = self.convert_indices_2_onehot(targets=self.train_Y2,nb_labels=self.nb_label)
            self.valid_label_one_hot_code = self.convert_indices_2_onehot(targets=self.valid_Y2,nb_labels=self.nb_label)
            self.test_label_one_hot_code = self.convert_indices_2_onehot(targets=self.test_Y2,nb_labels=self.nb_label)

        self.max_vector = dataset_obj.max_vector[1:]
        self.min_vector = dataset_obj.min_vector[1:]

        self.postprocess = dataset_obj.postprocess
        self.sampling_interval = dataset_obj.sampling_interval

        # Set up noise vector to generate seqeunces
        if self.prior_noise_type == 'Gaussian':
            mean = np.zeros(self.latent_dim)
            covariance = np.eye(N=self.latent_dim) * 1.0
            self.noise_vectors = generate_positive_samples(self.nb_to_generate/3,
                                                           mean, covariance,
                                                           'Gaussian', seed=1234)
        elif self.prior_noise_type =='Mixture':
            mean = np.zeros(self.latent_dim)
            covariance = np.eye(N=self.latent_dim) * 1.0
            self.noise_vectors = generate_positive_samples(self.nb_to_generate / 3,
                                                           mean, covariance,
                                                           type=self.prior_noise_type,
                                                           nb_mixture=self.nb_mixture,seed=1234)
        else:
            raise NotImplementedError()

    def convert_indices_2_onehot(self,targets, nb_labels):
        tmp_targets = targets.astype(int)
        ohm = np.zeros((tmp_targets.shape[0], nb_labels), dtype=np.float32)
        ohm[np.arange(tmp_targets.shape[0]), tmp_targets] = 1.0


        return ohm

    def set_up_noise_examples(self):
        """
        Creates noise samples that are used to constrain the encodings via the adversarial discriminator.
        """

        if self.prior_noise_type=='Gaussian':
            mean = np.zeros(self.latent_dim)  # Zero mean
            covariance = np.eye(N=self.latent_dim) * 1.0  # Variance of 1

            # Generate noise samples for training/ valid/ test sets
            self.positive_examples_training = generate_positive_samples(len(self.train_X),mean,covariance,'Gaussian',seed=np.random.randint(0,2000))
            self.positive_examples_valid = generate_positive_samples(len(self.valid_X), mean, covariance, 'Gaussian',seed=np.random.randint(0,2000))
            self.positive_examples_test = generate_positive_samples(len(self.test_X), mean, covariance, 'Gaussian',seed=np.random.randint(0,2000))

        elif self.prior_noise_type =='Mixture':
            mean = np.zeros(self.latent_dim)
            covariance = np.eye(N=self.latent_dim) * 1.0
            self.positive_examples_training = generate_positive_samples(len(self.train_X),
                                                                        mean,
                                                                        covariance,
                                                                        type=self.prior_noise_type,
                                                                        nb_mixture=self.nb_mixture,
                                                                        seed=np.random.randint(0, 2000))
            self.positive_examples_valid = generate_positive_samples(len(self.valid_X), mean, covariance,
                                                                     type=self.prior_noise_type,
                                                                     nb_mixture=self.nb_mixture,
                                                                     seed=np.random.randint(0, 2000))
            self.positive_examples_test = generate_positive_samples(len(self.test_X), mean, covariance,
                                                                    type=self.prior_noise_type,
                                                                    nb_mixture=self.nb_mixture,
                                                                    seed=np.random.randint(0, 2000))


        else:
            raise NotImplementedError()

    def Encoder_symetric(self):
        motion_input = Input(shape=(self.max_len, self.dof), name='encoder_input')
        encoded = motion_input

        # Declare the architecture of the encoder with either LSTM or GRU, and specified activation functions
        for i, (dim, activation) in enumerate(zip(self.hidden_dim_enc_list, self.activation_enc_list)):
            if i <len(self.hidden_dim_enc_list)-1:

                # Construct of recurrent layers using LSTM (if specified)
                if lstm_or_gru == 'lstm':
                    if activation == 'leakyrelu':
                        encoded = LSTM(output_dim=dim, return_sequences=True,
                            unit_forget_bias=self.forget_bias,
                            kernel_initializer=self.kernel_weight_initialization,
                            bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                        encoded = LeakyReLU(alpha=self.leaky_relu_alpha)(encoded)  #alpha=0.05
                    else:
                        encoded = LSTM(output_dim=dim, activation=activation, return_sequences=True,
                            unit_forget_bias=self.forget_bias,
                            kernel_initializer=self.kernel_weight_initialization,
                            bias_initializer=initializers.Constant(self.bias_initialization))(encoded)

                # Construct of recurrent layers using GRU instead
                elif lstm_or_gru == 'gru':
                    if activation == 'leakyrelu':
                        encoded = GRU(output_dim=dim, return_sequences=True,
                            unit_forget_bias=self.forget_bias,
                            kernel_initializer=self.kernel_weight_initialization,
                            bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                        encoded = LeakyReLU(alpha=self.leaky_relu_alpha)(encoded)  #alpha=0.05
                    else:
                        encoded = LSTM(output_dim=dim, activation=activation,
                            return_sequences=True, unit_forget_bias=self.forget_bias,
                            kernel_initializer=self.kernel_weight_initialization,
                            bias_initializer=initializers.Constant(self.bias_initialization))(encoded)

            # If we are at the second last gated layer, ensure that return_sequences=False
            else:
                if lstm_or_gru == 'lstm':
                    if activation == 'leakyrelu':
                        encoded = LSTM(output_dim=dim, return_sequences=False,
                            unit_forget_bias=self.forget_bias,
                            kernel_initializer=self.kernel_weight_initialization,
                            bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                        encoded = LeakyReLU(alpha=self.leaky_relu_alpha)(encoded)  #alpha=0.05
                    else:
                        encoded = LSTM(output_dim=dim, activation=activation, return_sequences=False,
                            unit_forget_bias=self.forget_bias,
                            kernel_initializer=self.kernel_weight_initialization,
                            bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                elif lstm_or_gru == 'gru':
                    if activation == 'leakyrelu':
                        encoded = GRU(output_dim=dim, return_sequences=False,
                            unit_forget_bias=self.forget_bias,
                            kernel_initializer=self.kernel_weight_initialization,
                            bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                        encoded = LeakyReLU(alpha=self.leaky_relu_alpha)(encoded)  #alpha=0.05
                    else:
                        encoded = LSTM(output_dim=dim, activation=activation, return_sequences=False,
                            unit_forget_bias=self.forget_bias,
                            kernel_initializer=self.kernel_weight_initialization,
                            bias_initializer=initializers.Constant(self.bias_initialization))(encoded)

        # Apply the final dense layer of the encoder to the transformed input
        encoded = Dense(output_dim=self.latent_dim, activation='linear')(encoded)  # Nonlinear activation function may be more suitable (sigmoid)


        return Model(input=motion_input, output=encoded, name='Encoder')


    def Encoder(self):
        """
        This is part of the architecture takes the input data (which is a
        matrix consisting of 200 frames of 69 joint angle values), and learns
        an encoding of this sequence of frames via a recurrent neural network
        implemented with either LSTMs or GRUs.
        """

        motion_input = Input(shape = (self.max_len,self.dof),name='encoder_input')
        encoded = motion_input

        # Add LSTMs/ GRUs to the model
        for i, (dim, activation) in enumerate(zip(self.hidden_dim_enc_list, self.activation_enc_list)):
            if self.lstm_or_gru=='lstm':
                if activation == 'leakyrelu':
                    encoded = LSTM(output_dim=dim, return_sequences=True,
                        unit_forget_bias=self.forget_bias,
                        kernel_initializer=self.kernel_weight_initialization,
                        bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                    encoded = LeakyReLU(alpha=self.leaky_relu_alpha)(encoded)  #alpha=0.05
                else:  # Use more standard activation functions
                    encoded = LSTM(output_dim=dim, activation=activation,
                        return_sequences=True, unit_forget_bias=self.forget_bias,
                        kernel_initializer=self.kernel_weight_initialization,
                        bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
            if self.lstm_or_gru=='gru':
                if activation == 'leakyrelu':
                    encoded = GRU(output_dim=dim, return_sequences=True,
                        unit_forget_bias=self.forget_bias,
                        kernel_initializer=self.kernel_weight_initialization,
                        bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                    encoded = LeakyReLU(alpha=self.leaky_relu_alpha)(encoded)  #alpha=0.05
                else:
                    encoded = GRU(output_dim=dim, activation=activation,
                        return_sequences=True, unit_forget_bias=self.forget_bias,
                        kernel_initializer=self.kernel_weight_initialization,
                        bias_initializer=initializers.Constant(self.bias_initialization))(encoded)

        # Latent layer: apply batch normalization to latent layer, if desired
        if self.latent_BN==True:
            if self.lstm_or_gru=='lstm':
                encoded = LSTM(output_dim=self.latent_dim, activation=self.latent_activation, name='encoded_layer',
                               return_sequences=False, unit_forget_bias=self.forget_bias,
                               kernel_initializer=self.kernel_weight_initialization,
                               bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                encoded = Dense(output_dim=self.latent_dim,activation='linear')(encoded)
                encoded = BatchNormalization(name='latent_BN')(encoded)
            if self.lstm_or_gru=='gru':
                encoded = GRU(output_dim=self.latent_dim, activation=self.latent_activation, name='encoded_layer',
                               return_sequences=False, unit_forget_bias=self.forget_bias,
                               kernel_initializer=self.kernel_weight_initialization,
                               bias_initializer=initializers.Constant(self.bias_initialization))(encoded)
                encoded = Dense(output_dim=self.latent_dim,activation='linear')(encoded)
                encoded = BatchNormalization(name='latent_BN')(encoded)

        # Do not apply batch normalization to latent layer, if desired
        else:
            # Ensure final layers have return_sequences=False
            if self.lstm_or_gru=='lstm':
                encoded = LSTM(output_dim=self.latent_dim,activation=self.latent_activation,
                    name = 'encoded_layer',return_sequences=False, unit_forget_bias=self.forget_bias,
                    kernel_initializer=self.kernel_weight_initialization,
                    bias_initializer=initializers.Constant(self.bias_initialization))(encoded)   # unit_forget_bias=True,
                encoded = Dense(output_dim=self.latent_dim, activation='linear')(encoded)
            if self.lstm_or_gru=='gru':
                encoded = GRU(output_dim=self.latent_dim,activation=self.latent_activation,
                    name = 'encoded_layer',return_sequences=False,
                    unit_forget_bias=self.forget_bias,
                    kernel_initializer=self.kernel_weight_initialization,
                    bias_initializer=initializers.Constant(self.bias_initialization))(encoded)   # unit_forget_bias=True,
                encoded = Dense(output_dim=self.latent_dim, activation='linear')(encoded)


        return Model(input=motion_input, output=encoded, name='Encoder')


    def Decoder(self):
        """
        This function creates the decoder part of the model, which takes as
        input both the encoding learned from the encoder, but also for this
        specific style-free adversarial sequence autoencoder conditional model,
        also takes as input a style label which can be either be the emotion
        or action label. From this encoding and label, the decoder outputs
        a reconstruction of the original input from the encoding, generating a
        new sequence.
        """

        latent_input = Input(shape=(self.latent_dim,),name='latent_input')
        latent_input_seq = RepeatVector(self.max_len)(latent_input)
        label_input = Input(shape=(self.nb_label,), name='label_input')

        if self.embedding_dim != 0:
            label_seq = Dense(units=self.embedding_dim,activation='tanh',use_bias=False,
                                kernel_initializer='uniform')(label_input)
        else:
            label_seq = label_input
        label_seq = RepeatVector(self.max_len)(label_seq)  # Repeats the label_seq, max_len times so it becomes of shape (None, max_len, len(label_seq))
        decoded = concatenate([latent_input_seq,label_seq])

        # Add LSTMs/ GRUs to the RNN decoder, as specified by the user
        for i,(dim, activation) in enumerate(zip(self.hidden_dim_dec_list,self.activation_dec_list)):

            # Construct using LSTM
            if self.lstm_or_gru=='lstm':
                if activation == 'leakyrelu':
                    decoded = LSTM(output_dim=dim, return_sequences=True,
                        unit_forget_bias=self.forget_bias,
                        kernel_initializer=self.kernel_weight_initialization,
                        bias_initializer=initializers.Constant(self.bias_initialization))(decoded)
                    decoded = LeakyReLU(alpha=self.leaky_relu_alpha)(decoded)  #alpha=0.05
                else:
                    decoded = LSTM(output_dim=dim, activation=activation,
                        return_sequences=True, unit_forget_bias=self.forget_bias,
                        kernel_initializer=self.kernel_weight_initialization,
                        bias_initializer=initializers.Constant(self.bias_initialization))(decoded)

            # Construct using GRU
            elif self.lstm_or_gru=='gru':
                if activation == 'leakyrelu':
                    decoded = GRU(output_dim=dim, return_sequences=True,
                        unit_forget_bias=self.forget_bias,
                        kernel_initializer=self.kernel_weight_initialization,
                        bias_initializer=initializers.Constant(self.bias_initialization))(decoded)
                    decoded = LeakyReLU(alpha=self.leaky_relu_alpha)(decoded)  #alpha=0.05
                else:
                    decoded = GRU(output_dim=dim, activation=activation, return_sequences=True,
                        unit_forget_bias=self.forget_bias,
                        kernel_initializer=self.kernel_weight_initialization,
                        bias_initializer=initializers.Constant(self.bias_initialization))(decoded)

            if self.fully_condition:
                # decoded = merge([decoded,label_seq],mode='concat')
                decoded = concatenate([decoded,label_seq])

        decoded = SimpleRNN(output_dim=self.dof,activation='sigmoid',name='decoder_output',return_sequences=True)(decoded)


        return Model(input = [latent_input,label_input], output=decoded,name='Decoder')


    def Discriminator(self):
        """
        Discriminates (classifies) between fake/true encodings which correspond
        to sequences, via adversarial learning.
        """

        input = Input(shape=(self.latent_dim,),name='discmt_input')

        # Construct the layers of the discriminator model
        for i,(dim,activation,dropout) in enumerate(zip(self.hidden_dim_dis_list, self.activation_dis_list,self.dropout_dis_list)):

            # If we are at the very first layer
            if i == 0:
                if activation == 'leakyrelu':
                    discmt = Dense(dim)(input)
                    discmt = LeakyReLU(alpha=self.leaky_relu_alpha)(discmt)  #alpha=0.05
                else:
                    discmt = Dense(dim,activation=activation)(input)

            # If we are past the first layer, apply dropout if specified
            else:
                discmt = Dropout(dropout)(discmt)
                if activation == 'leakyrelu':
                    discmt = Dense(dim)(discmt)
                    discmt = LeakyReLU(alpha=self.leaky_relu_alpha)(discmt)  #alpha=0.05
                else:
                    discmt = Dense(dim,activation=activation)(discmt)

        # Final layer of the discriminator, provide an output dimension of 1
        discmt = Dense(1,activation='sigmoid',name='discmt_output')(discmt)

        return Model(input=input,output=discmt,name='Discmt')


    def Classifier(self):
        """
        Classifies the style (emotion/ activity) label of the input data using
        a simple feedforward neural network.
        """

        input = Input(shape=(self.latent_dim,), name='classifier_input')

        # Construct the layers of the style classifier model
        for i, (dim, activation, dropout) in enumerate(zip(self.hidden_dim_classifier_list, self.activation_classifier_list, self.dropout_classifier_list)):

            # If we are at the very first layer
            if i == 0:
                if activation == 'leakyrelu':
                    discmt = Dense(dim)(input)
                    discmt = LeakyReLU(alpha=self.leaky_relu_alpha)(discmt)  #alpha=0.05
                else:
                    discmt = Dense(dim, activation=activation)(input)

            # Apply dropout at consecutive layers, if specified
            else:
                discmt = Dropout(dropout)(discmt)  # Dropout
                if activation == 'leakyrelu':
                    discmt = Dense(dim)(discmt)
                    discmt = LeakyReLU(alpha=self.leaky_relu_alpha)(discmt)  #alpha=0.05
                else:
                    discmt = Dense(dim, activation=activation)(discmt)

        # Final layer of the model to predict the integer label encoded style
        discmt = Dense(self.nb_label, activation='softmax', name='classifier_output')(discmt)


        return Model(input=input, output=discmt, name='Classifier')


    def Autoencoder_with_Discmt(self):
        """
        This is the full overall model, consisting of the encoder, decoder,
        adversarial discriminator, and style discriminator (classifier).
        Takes as input a training sequence, and provides as output a generated
        sequence of 200 frames long.

        Output:
        * List of length 3
        * [0] of list is a 200*69 matrix corresponding to predictions of 69
        joint angles for 200 frames
        * [1] of list is a 200*1 matrix, corresponding to whether the movement
        is adversarially discriminated as being True/ False (real encodings,
        or generated fromnoise samples)
        * [2] of list is a 200*8 matrix, corresponding to the predicted style
        of the movement, which is one-hot-encoded from 0 to 7.
        """

        autoencoder = self.decoder([self.encoder.output, self.decoder.inputs[1]])
        self.discriminator.trainable = False
        self.classifier.trainable = False
        aux_output_discmt = self.discriminator(self.encoder.output)
        aux_output_classifier =  self.classifier(self.encoder.output)


        return Model(input=[self.encoder.input,self.decoder.inputs[1]],
                     output=[autoencoder, aux_output_discmt,aux_output_classifier],
                     name='Autoencoder_with_Dis')


    def compile(self):
        """
        Compiles, and trains the model using a specified optimization method.
        """

        # Train the autoencoder via an optimization method
        if self.optimiser_autoencoder =='sgd':
            optimizer_ae = SGD(lr=self.lr_autoencoder,decay=self.decay_autoencoder, clipnorm=self.clip_norm)
        elif self.optimiser_autoencoder =='rmsprop':
            optimizer_ae = RMSprop(lr=self.lr_autoencoder,decay=self.decay_autoencoder, clipnorm=self.clip_norm)
        elif self.optimiser_autoencoder =='adam':
            optimizer_ae = Adam(lr=self.lr_autoencoder,decay=self.decay_autoencoder, clipnorm=self.clip_norm)

        # Train the discriminator via an optimization method
        if self.optimiser_dis =='sgd':
            optimizer_discmt = SGD(lr=self.lr_dis,decay=self.decay_dis, clipnorm=self.clip_norm)
        elif self.optimiser_dis =='adam':
            optimizer_discmt = Adam(lr=self.lr_dis,decay=self.decay_dis, clipnorm=self.clip_norm)
        elif self.optimiser_dis =='rmsprop':
            optimizer_discmt = RMSprop(lr=self.lr_dis, decay=self.decay_dis, clipnorm=self.clip_norm)

        # Not an RNN, so no need to worry about vanishing gradient
        if self.optimiser_classifier =='sgd':
            optimizer_classifier = SGD(lr=self.lr_classifier,decay=self.decay_classifier)
        elif self.optimiser_classifier =='adam':
            optimizer_classifier = Adam(lr=self.lr_classifier,decay=self.decay_classifier)
        elif self.optimiser_classifier =='rmsprop':
            optimizer_classifier = RMSprop(lr=self.lr_classifier,decay=self.decay_classifier)

        self.discriminator.trainable = True
        self.discriminator.compile(optimizer_discmt,loss='binary_crossentropy',metrics=['accuracy'])
        self.discriminator.trainable = False
        self.classifier.trainable =True
        self.classifier.compile(optimizer_classifier,loss='categorical_crossentropy',metrics=['accuracy'])
        self.classifier.trainable = False

        if self.custom_loss==True:
            self.autoencoder_with_discriminator.compile(optimizer_ae, \
                                                        loss={'Decoder': self.loss_mse_velocity_loss, \
                                                              'Discmt': 'binary_crossentropy',
                                                              'Classifier':self.loss_neg_entropy}, \
                                                        loss_weights=self.loss_weights,
                                                        metrics={'Decoder':'mse'})

        else:
            self.autoencoder_with_discriminator.compile(optimizer_ae,\
                                                        loss={'Decoder':'mse',\
                                                              'Discmt':'binary_crossentropy',
                                                              'Classifier':self.loss_neg_entropy},\
                                                        loss_weights = self.loss_weights,
                                                        metrics={'Decoder': 'mse'})

    def loss_mse_velocity_loss(self,y_true,y_pred):
        """
        This is an additional delta term, which is used when implementing a
        variant of the autoencoder which is trained to not only optimize a
        reconstruction loss, but instead to also optimize a reconstruction of
        the first order derivatives of the frames (i.e. velocity).

        The purpose of this loss term enforces the model to output a sequence
        whose dynamics are closer to that of the input sequence, to provide
        more realistic animation.
        """

        mse = K.mean(K.square(y_pred-y_true))  # Reconstruction loss
        mse_v = K.mean(K.square((y_pred[:,1:,:] - y_pred[:,0:-1,:]) \
            -(y_true[:,1:,:] - y_true[:,0:-1,:])))  # additional delta term


        return mse + (self.alpha * mse_v)  # Return reconstruction + delta (weighted by self.alpha = loss_weight_mse_v)


    def loss_neg_entropy(self,y_true,y_pred):
        """
        This is a cross entropy term used to train the emotion classifier.
        """

        y_pred/= K.sum(y_pred, axis=-1, keepdims=True)
        y_pred = K.clip(y_pred, K.epsilon(), 1.0 - K.epsilon())  # avoid numerical instability with _EPSILON clipping


        return self.beta_classifier * K.sum(y_pred * K.log(y_pred), axis=(K.ndim(y_pred) - 1))


    def init_loss_history_list(self):
        """
        Initializes a dictionary which tracks the loss functions as training
        progresses. This helps us visualize/ track how our model is improving
        overtime, and is helpful for debugging purposes.
        """

        self.loss_history = {"training_loss_discriminator": [],
                             "training_loss_mse_autoencoder": [],
                             "training_loss_crossentropy_encoder":[],
                             'training_loss_classifier':[],
                             "traning_loss_neg_entropy_encoder":[],
                             "training_accuracy_classifier":[],
                             "training_metric_mse":[],
                             "training_metric_mse_v":[],
                             "valid_loss_discriminator": [],
                             "valid_loss_mse_autoencoder": [],
                             "valid_loss_crossentropy_encoder":[],
                             'valid_loss_classifier': [],
                             "valid_loss_neg_entropy_encoder": [],
                             "valid_accuracy_classifier": [],
                             "valid_metric_mse": [],
                             "valid_metric_mse_v": [],
                             "beta_classifier":[],
                             "training_total_loss":[],
                             "valid_total_loss":[]
                             }

    def print_loss_history(self):
        """
        Prints to the terminal the values of the loss functions which are to
        be optimized. Useful for debugging purposes and to ensure that our
        model is training correctly.
        """

        for loss_key in sorted(self.loss_history.keys()):
            print "%s:%f"%(loss_key,self.loss_history[loss_key][-1])


    def plot_latent_space(self,latent_codes,filename,Y1=None,Y2=None,dim_x=0,dim_y=1):
        """
        Visualizes the latent space of the encoder.
        """

        if Y1 is None:
            Y1 = np.zeros(len(latent_codes), dtype=np.float32)
        if Y2 is None:
            Y2 = np.zeros(Y1.shape, dtype=np.float32)
        nb_act = len(np.unique(Y1))
        nb_em = len(np.unique(Y2))
        fig = plt.figure(figsize=(8, 8))
        color = plt.cm.rainbow(np.linspace(0, 1, nb_act * nb_em))
        # print np.unique(Y)
        for l, c in zip(range(nb_act * nb_em), color):
            y1 = l / nb_em
            y2 = l % nb_em
            idx_1 = np.where(Y1 == y1)[0]
            idx_2 = np.where(Y2 == y2)[0]
            idx = list(set(idx_1).intersection(idx_2))
            plt.scatter(latent_codes[idx, dim_x], latent_codes[idx, dim_y], c=c, label=l, s=8, linewidths=0)
            # plt.xlim([-5.0,5.0])
            # plt.ylim([-5.0,5.0])
        plt.legend(fontsize=15)
        plt.savefig(filename)
        plt.close(fig)



    def compute_loss_and_plot_latent_space(self,epoch,whichdataset='training'):
        """
        Computes the loss of the model, so we can verify its accuracy and
        the latent space of the encoder. We should expect that in the latent
        space different classes of generated movement (e.g. emotions) are
        seperated in well defined clusters, and that there is large distance
        between these clusters.
        """

        if whichdataset=='training':
            dataset = self.train_X
            Y1 = self.train_Y1
            Y2 = self.train_Y2
            positive_examples = self.positive_examples_training  # These are noise samples
            label_one_hot_code = self.train_label_one_hot_code

        elif whichdataset =='valid':
            dataset = self.valid_X
            Y1 = self.valid_Y1
            Y2 = self.valid_Y2
            positive_examples = self.positive_examples_valid
            label_one_hot_code = self.valid_label_one_hot_code

        elif whichdataset == 'test':
            dataset = self.test_X
            Y1 = self.test_Y1
            Y2 = self.test_Y2
            positive_examples = self.positive_examples_test
            label_one_hot_code = self.test_label_one_hot_code

        else:
            raise ValueError('wrong argument whichdataset')

        num_samples = len(dataset)
        latent_codes = self.encoder.predict(x=dataset,batch_size=1000,verbose=0)

        # Plot latent space
        if epoch %self.checkpoint_epochs==0:
            filename = 'Epoch' + str(epoch) + '_' + whichdataset + '01.png'
            self.plot_latent_space(latent_codes,filename,Y1,dim_x=0,dim_y=1)
            filename = 'Epoch' + str(epoch) + '_' + whichdataset + '23.png'
            self.plot_latent_space(latent_codes, filename, Y1, dim_x=2, dim_y=3)

        X = np.concatenate((positive_examples, latent_codes),axis=0)  # Input: noise samples combined with predicted encodings (predicted latent codes of encoder)
        Y = [1.]*num_samples +[0.]*num_samples  # Ouptut: [1,.....,0,...] corresponding to fake/ real (i.e. noise/ encodings)

        #=========================
        # Loss functions
        #=========================

        # Accuracy in discriminating between noise and real encodings
        loss_dis, accuracy_dis = self.discriminator.evaluate(X,Y,batch_size=1000,verbose=0)

        # Accuracy in predicting style labels (label_one_hot_code) using encodings (latent_codes)
        loss_classifier,accuracy_classifier = self.classifier.evaluate(x=latent_codes, y=label_one_hot_code, batch_size=1000,verbose=0)

        # A vector corresponding to predicting True (1) encodings (as opposed to noise, 0) in the classifier
        Y_hat = np.asarray([1.] * num_samples)

        # Compute losses (loss, decoder_loss, discriminator loss (discmt_loss), classifier_loss, decoder_mean_squared_error)
        total_loss, loss_autoencoder,loss_crossentropy_encoder,loss_neg_entropy_encoder, metric_mse \
        = self.autoencoder_with_discriminator.evaluate(x=[dataset,label_one_hot_code],
                                                         y={'Decoder':dataset,  # Score how well input is reconstructed by decoder
                                                            'Discmt':Y_hat,  # Score how well the encoded input is discriminated from fake noise encodings
                                                            'Classifier':Y_hat},  # Score how well the encoded input is classified as true encodings (appears wrong)

                                                            batch_size=1000,verbose=0)

        metric_mse_v = K.eval((loss_autoencoder - metric_mse) / self.alpha)  # alpha weights how much this MSE contributes to the overall loss function
        loss_neg_entropy_encoder = K.eval(loss_neg_entropy_encoder / self.beta_classifier)  # beta weights how much the negative entropy of the encoder contributes to overall loss function

        if whichdataset=='training':
            self.loss_history["training_loss_discriminator"].append(loss_dis)
            self.loss_history["training_loss_mse_autoencoder"].append(loss_autoencoder)
            self.loss_history["training_loss_crossentropy_encoder"].append(loss_crossentropy_encoder)
            self.loss_history['training_loss_classifier'].append(loss_classifier)
            self.loss_history['traning_loss_neg_entropy_encoder'].append(loss_neg_entropy_encoder)
            self.loss_history['training_accuracy_classifier'].append(accuracy_classifier)
            self.loss_history["training_metric_mse"].append(metric_mse)
            self.loss_history["training_metric_mse_v"].append(metric_mse_v)  # alpha weights how much this MSE contributes to the overall loss function
            self.loss_history["training_total_loss"].append(total_loss)

        elif whichdataset=='valid':
            self.loss_history["valid_loss_discriminator"].append(loss_dis)
            self.loss_history["valid_loss_mse_autoencoder"].append(loss_autoencoder)
            self.loss_history["valid_loss_crossentropy_encoder"].append(loss_crossentropy_encoder)  # beta weights how much the negative entropy of the encoder contributes to overall loss function
            self.loss_history['valid_loss_classifier'].append(loss_classifier)
            self.loss_history['valid_loss_neg_entropy_encoder'].append(loss_neg_entropy_encoder)
            self.loss_history['valid_accuracy_classifier'].append(accuracy_classifier)
            self.loss_history["valid_metric_mse"].append(metric_mse)
            self.loss_history["valid_metric_mse_v"].append(metric_mse_v)
            self.loss_history["valid_total_loss"].append(total_loss)

        elif whichdataset=='test':
            raise NotImplementedError()


    def plot_loss(self):
        """
        Visualizes the loss functions of all the terms (reconstruction loss,
        reconstruction loss + first order derivatives term, and adversarial
        losses) as subplots in a single super plot, over the training epochs.

        The figure is continuously updated after each training epoch.
        """

        # Reconstruction loss of autoencoder (MSE)
        fig = plt.figure(figsize=(8, 8))

        # # MSE weighted by beta hyperparameter and delta term
        # plt.subplot(8, 1, 1)
        # legend_str = []
        # plt.plot(self.loss_history['training_total_loss'])
        # legend_str.append('Training Loss:%f' % self.loss_history['training_total_loss'][-1])
        # plt.plot(self.loss_history['valid_total_loss'])
        # legend_str.append(
        #     'Validation Loss:%f' % self.loss_history['valid_total_loss'][-1])
        # plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        # plt.xlabel('Epoch Number')
        # plt.ylabel('Total Loss')  # MSE velocity (delta term, including first-order \n derivatives of reconstruction loss)

        plt.subplot(2,2,1)
        legend_str = []
        plt.plot(self.loss_history['training_metric_mse'])
        legend_str.append('Training Loss:%f' % self.loss_history['training_metric_mse'][-1])
        plt.plot(self.loss_history['valid_metric_mse'])
        legend_str.append(
            'Validation Loss:%f' % self.loss_history['valid_metric_mse'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('MSE')

        # Adversarial discriminator loss (Noise/ Real)
        plt.subplot(2,2,2)
        legend_str = []
        plt.plot(self.loss_history['training_loss_discriminator'])
        legend_str.append('Training Loss:%f'%self.loss_history['training_loss_discriminator'][-1])
        plt.plot(self.loss_history['valid_loss_discriminator'])
        legend_str.append('Validation Loss:%f' % self.loss_history['valid_loss_discriminator'][-1])
        plt.legend(legend_str,fontsize=10,loc='best',fancybox=True,framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('Adversarial Loss of Discriminator (real/fake)')

        #
        plt.subplot(2, 2, 3)
        legend_str = []
        plt.plot(self.loss_history['training_accuracy_classifier'])
        legend_str.append('Training Accuracy:%f' % self.loss_history['training_accuracy_classifier'][-1])
        plt.plot(self.loss_history['valid_accuracy_classifier'])
        legend_str.append(
            'Validation Accuracy:%f' % self.loss_history['valid_accuracy_classifier'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('Emotion classifier accuracy')

        plt.subplot(2, 2, 4)
        legend_str = []
        plt.plot(self.loss_history['traning_loss_neg_entropy_encoder'])
        legend_str.append('Training Loss:%f' % self.loss_history['traning_loss_neg_entropy_encoder'][-1])
        plt.plot(self.loss_history['valid_loss_neg_entropy_encoder'])
        legend_str.append(
            'Validation Loss:%f' % self.loss_history['valid_loss_neg_entropy_encoder'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('Negative cross entropy of encoder')

        plt.tight_layout()
        plt.savefig('./horizontal_learning_curve.png', dpi=300)
        plt.close(fig)

        plt.subplot(8, 1, 1)
        legend_str = []
        plt.plot(self.loss_history['training_metric_mse'])
        legend_str.append('Training Loss:%f' % self.loss_history['training_metric_mse'][-1])
        plt.plot(self.loss_history['valid_metric_mse'])
        legend_str.append(
            'Validation Loss:%f' % self.loss_history['valid_metric_mse'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('MSE')

        #
        plt.subplot(8, 1, 2)
        legend_str = []
        plt.plot(self.loss_history['training_metric_mse'])
        legend_str.append('Training Loss:%f' % self.loss_history['training_metric_mse'][-1])
        plt.plot(self.loss_history['valid_metric_mse'])
        legend_str.append(
            'Validation Loss:%f' % self.loss_history['valid_metric_mse'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('MSE')

        # MSE weighted by beta hyperparameter and delta term
        plt.subplot(8, 1, 3)
        legend_str = []
        plt.plot(self.loss_history['training_metric_mse_v'])
        legend_str.append('Training Loss:%f' % self.loss_history['training_metric_mse_v'][-1])
        plt.plot(self.loss_history['valid_metric_mse_v'])
        legend_str.append(
            'Validation Loss:%f' % self.loss_history['valid_metric_mse_v'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('MSE velocity loss')  # MSE velocity (delta term, including first-order \n derivatives of reconstruction loss)

        # Adversarial discriminator loss (Noise/ Real)
        plt.subplot(8,1,4)
        legend_str = []
        plt.plot(self.loss_history['training_loss_discriminator'])
        legend_str.append('Training Loss:%f'%self.loss_history['training_loss_discriminator'][-1])
        plt.plot(self.loss_history['valid_loss_discriminator'])
        legend_str.append('Validation Loss:%f' % self.loss_history['valid_loss_discriminator'][-1])
        plt.legend(legend_str,fontsize=10,loc='best',fancybox=True,framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('Adversarial Loss on discriminating between \n encodings of real data and fake noise data')

        # Cross-entropy loss of style classifier discriminator (?). 2nd term of overall loss function. This appears to be increasing. By increasing cross entropy of encoder, we decrease the overall
        plt.subplot(8,1,5)
        legend_str = []
        plt.plot(self.loss_history['training_loss_crossentropy_encoder'])
        legend_str.append('Training Loss:%f' % self.loss_history['training_loss_crossentropy_encoder'][-1])
        plt.plot(self.loss_history['valid_loss_crossentropy_encoder'])
        legend_str.append('Validation Loss:%f' % self.loss_history['valid_loss_crossentropy_encoder'][-1])
        plt.legend(legend_str,fontsize=10,loc='best',fancybox=True,framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('Cross-entropy loss of Encoder')

        # Loss of of style classifier
        plt.subplot(8, 1, 6)
        legend_str = []
        plt.plot(self.loss_history['training_loss_classifier'])
        legend_str.append('Training Loss:%f' % self.loss_history['training_loss_classifier'][-1])
        plt.plot(self.loss_history['valid_loss_classifier'])
        legend_str.append(
            'Validation Loss:%f' % self.loss_history['valid_loss_classifier'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('Classifier Loss')

        #
        plt.subplot(8, 1, 7)
        legend_str = []
        plt.plot(self.loss_history['training_accuracy_classifier'])
        legend_str.append('Training Accuracy:%f' % self.loss_history['training_accuracy_classifier'][-1])
        plt.plot(self.loss_history['valid_accuracy_classifier'])
        legend_str.append(
            'Validation Accuracy:%f' % self.loss_history['valid_accuracy_classifier'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('Emotion classifier accuracy')

        plt.subplot(8, 1, 8)
        legend_str = []
        plt.plot(self.loss_history['traning_loss_neg_entropy_encoder'])
        legend_str.append('Training Loss:%f' % self.loss_history['traning_loss_neg_entropy_encoder'][-1])
        plt.plot(self.loss_history['valid_loss_neg_entropy_encoder'])
        legend_str.append(
            'Validation Loss:%f' % self.loss_history['valid_loss_neg_entropy_encoder'][-1])
        plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
        plt.xlabel('Epoch Number')
        plt.ylabel('Negative cross entropy of encoder')

        plt.tight_layout()
        plt.savefig('./learning_curve.png')
        plt.close(fig)

        #------------
        # Generate Individual Plots
        #------------

        generate_individual_plots=True
        if generate_individual_plots == True:

            plt.subplot(1,1,1)
            legend_str =[]
            plt.plot(self.loss_history["training_loss_mse_autoencoder"])
            legend_str.append('Training Loss'+':%f' % self.loss_history["training_loss_mse_autoencoder"][-1])
            plt.plot(self.loss_history["valid_loss_mse_autoencoder"])
            legend_str.append('Validation Loss'+':%f' % self.loss_history["valid_loss_mse_autoencoder"][-1])
            plt.legend(legend_str,fontsize=10,loc='best',fancybox=True,framealpha=0.5)
            plt.xlabel('Epoch Number')
            plt.ylabel('Reconstruction loss of autoencoder \n (MSE + weighted velocity loss)')
            plt.savefig('./training_accuracy_classifier.png', dpi=300)
            plt.close(fig)

            #
            fig = plt.figure(figsize=(5, 5))
            plt.subplot(1,1,1)
            legend_str = []
            plt.plot(self.loss_history['training_metric_mse'])
            legend_str.append('Training Loss:%f' % self.loss_history['training_metric_mse'][-1])
            plt.plot(self.loss_history['valid_metric_mse'])
            legend_str.append(
                'Validation Loss:%f' % self.loss_history['valid_metric_mse'][-1])
            plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
            plt.xlabel('Epoch Number')
            plt.ylabel('MSE')
            plt.savefig('./training_accuracy_classifier.png', dpi=300)
            plt.close(fig)

            # MSE weighted by beta hyperparameter and delta term
            fig = plt.figure(figsize=(5, 5))
            plt.subplot(1,1,1)
            legend_str = []
            plt.plot(self.loss_history['training_metric_mse_v'])
            legend_str.append('Training Loss:%f' % self.loss_history['training_metric_mse_v'][-1])
            plt.plot(self.loss_history['valid_metric_mse_v'])
            legend_str.append(
                'Validation Loss:%f' % self.loss_history['valid_metric_mse_v'][-1])
            plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
            plt.xlabel('Epoch Number')
            plt.ylabel('MSE velocity loss')  # MSE velocity (delta term, including first-order \n derivatives of reconstruction loss)
            plt.savefig('./training_accuracy_classifier.png', dpi=300)
            plt.close(fig)

            # Adversarial discriminator loss (Noise/ Real)
            fig = plt.figure(figsize=(5, 5))
            plt.subplot(1,1,1)
            legend_str = []
            plt.plot(self.loss_history['training_loss_discriminator'])
            legend_str.append('Training Loss:%f'%self.loss_history['training_loss_discriminator'][-1])
            plt.plot(self.loss_history['valid_loss_discriminator'])
            legend_str.append('Validation Loss:%f' % self.loss_history['valid_loss_discriminator'][-1])
            plt.legend(legend_str,fontsize=10,loc='best',fancybox=True,framealpha=0.5)
            plt.xlabel('Epoch Number')
            plt.ylabel('Adversarial Loss on discriminating between \n encodings of real data and fake noise data')
            plt.savefig('./training_accuracy_classifier.png', dpi=300)
            plt.close(fig)

            # Cross-entropy loss of style classifier discriminator (?). 2nd term of overall loss function. This appears to be increasing. By increasing cross entropy of encoder, we decrease the overall
            fig = plt.figure(figsize=(5, 5))
            plt.subplot(1,1,1)
            legend_str = []
            plt.plot(self.loss_history['training_loss_crossentropy_encoder'])
            legend_str.append('Training Loss:%f' % self.loss_history['training_loss_crossentropy_encoder'][-1])
            plt.plot(self.loss_history['valid_loss_crossentropy_encoder'])
            legend_str.append('Validation Loss:%f' % self.loss_history['valid_loss_crossentropy_encoder'][-1])
            plt.legend(legend_str,fontsize=10,loc='best',fancybox=True,framealpha=0.5)
            plt.xlabel('Epoch Number')
            plt.ylabel('Cross-entropy loss of Encoder')
            plt.savefig('./training_accuracy_classifier.png', dpi=300)
            plt.close(fig)

            # Loss of of style classifier
            fig = plt.figure(figsize=(5, 5))
            plt.subplot(1,1,1)
            legend_str = []
            plt.plot(self.loss_history['training_loss_classifier'])
            legend_str.append('Training Loss:%f' % self.loss_history['training_loss_classifier'][-1])
            plt.plot(self.loss_history['valid_loss_classifier'])
            legend_str.append(
                'Validation Loss:%f' % self.loss_history['valid_loss_classifier'][-1])
            plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
            plt.xlabel('Epoch Number')
            plt.ylabel('Classifier Loss')
            plt.savefig('./training_accuracy_classifier.png', dpi=300)
            plt.close(fig)

            fig = plt.figure(figsize=(5, 5))
            plt.subplot(1, 1, 1)
            legend_str = []
            plt.plot(self.loss_history['training_accuracy_classifier'])
            legend_str.append('Training Accuracy:%f' % self.loss_history['training_accuracy_classifier'][-1])
            plt.plot(self.loss_history['valid_accuracy_classifier'])
            legend_str.append(
                'Validation Accuracy:%f' % self.loss_history['valid_accuracy_classifier'][-1])
            plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
            plt.xlabel('Epoch Number')
            plt.ylabel('Emotion classifier accuracy')
            plt.savefig('./training_accuracy_classifier.png', dpi=300)
            plt.close(fig)

            fig = plt.figure(figsize=(5, 5))
            plt.subplot(1, 1, 1)
            legend_str = []
            plt.plot(self.loss_history['traning_loss_neg_entropy_encoder'])
            legend_str.append('Training Loss:%f' % self.loss_history['traning_loss_neg_entropy_encoder'][-1])
            plt.plot(self.loss_history['valid_loss_neg_entropy_encoder'])
            legend_str.append(
                'Validation Loss:%f' % self.loss_history['valid_loss_neg_entropy_encoder'][-1])
            plt.legend(legend_str, fontsize=10, loc='best', fancybox=True, framealpha=0.5)
            plt.xlabel('Epoch Number')
            plt.ylabel('Negative cross entropy of encoder')
            plt.tight_layout()
            plt.savefig('./traning_loss_neg_entropy_encoder.png', dpi=300)
            plt.close(fig)

    def training(self,dataset_obj):
        """
        Trains the entire style free adversarial sequential autoencoder model.
        """

        # Initialization
        self.set_up_dataset(dataset_obj)
        self.set_up_model()
        self.init_loss_history_list()
        all_weights = []  # For simply recording the weights

        # Train over the specified number of epochs
        for epoch in range(self.max_epoch):
            print('Epoch seen: {}'.format(epoch))
            print "alpha = {}".format(K.eval(self.alpha))

            # Update the learning rate of the autoencoder as a function of the
            # number of training iterations and specified decay parameter
            self.cur_lr_autoencoder = self.autoencoder_with_discriminator.optimizer.lr \
                * (1. / (1. + self.autoencoder_with_discriminator.optimizer.decay \
                * tf.to_float(self.autoencoder_with_discriminator.optimizer.iterations)))

            print "current learning rate of autoencoder: {}".format(K.eval(self.cur_lr_autoencoder))

            # Beta is the coefficient which weights how much the loss of the
            # classifier contributes to the overall loss.
            print "current beta_classifier value is {}".format(K.eval(self.beta_classifier+0.0))
            self.loss_history['beta_classifier'].append(K.eval(self.beta_classifier+0.0))  # Record updated beta (as it gets updated via annealing_beta)

            self.set_up_noise_examples()  # Create random noise encodings of sequences
            self.compute_loss_and_plot_latent_space(epoch,'training')  # Plot the encodings of the training sequences
            self.compute_loss_and_plot_latent_space(epoch,'valid')  # Plot the encodings of the validation sequences
            self.print_loss_history()  # Print the losses at the current timestep
            self.plot_loss()  # Visualize the loss functions so far in the training

            self.training_loop(self.train_X,  # Joint angles
                                self.train_label_one_hot_code,  # Style label
                                self.positive_examples_training,  # Encodings of random noise (shape is 200*latent_dim), which discriminator will compare with true encodings
                                batch_size=self.batch_size)

            # Save generated sequences at each specified check-point
            if epoch %self.checkpoint_epochs==0:
                self.save_models(suffix=str(epoch))


                # just_simple_walk = True
                # generate_each_style_explicitly = True
                # style_label = 0
                #
                # if (just_simple_walk == True) and (generate_each_style_explicitly == True):
                #     # for style_label in range(0,7):
                #     print style_label
                #     print 's'
                #     reconstruced_seqs, output_discriminator,output_classifier = self.autoencoder_with_discriminator.predict(
                #         [self.test_X[np.where((self.test_Y1 == 2) & (self.test_Y2 == style_label))],  # where activity is simple walk, and emotion is of specified style
                #         self.test_label_one_hot_code[:self.nb_to_generate]])
                #
                # else:
                # reconstruced_seqs, output_discriminator,output_classifier = self.autoencoder_with_discriminator.predict([self.test_X[:self.nb_to_generate],
                #                                                                                    self.test_label_one_hot_code[:self.nb_to_generate]])
                # # Original input sequences used in testing stage, to generate new sequences
                # print self.test_Y1  # activity
                # print self.test_Y2  # emotion
                # print self.test_Y1.shape
                # print self.test_X.shape
                # print self.test_Y2.shape
                #
                # # print(np.where(self.test_Y1 == 2))  # Where the label is 'simple walk'
                # # print np.take((self.test_X), np.where(self.test_Y1 == 2))  # Return sequences that are 'simple walk'
                # print self.test_X[np.where(self.test_Y1 == 2)].shape
                # print self.test_X[np.where(self.test_Y1 == 2)]  # Return only 'simple walk' sequences

                # print '------------------'
                #
                # just_simple_walk = True
                # if (just_simple_walk == True) and (generate_each_style_explicitly == True):
                #     # self.save_generated_seqs(self.test_X[np.where((self.test_Y1 == 2))) and np.where((self.test_Y2 == style_label))],  # where activity is simple walk, and emotion is of specified style
                #     self.save_generated_seqs(self.test_X[np.where(self.test_Y1 == 2)],  # where activity is simple walk, and emotion is of specified style
                #                              max_vector=self.max_vector,
                #                              min_vector=self.min_vector,
                #                              suffix='original_input_simplewalk',epoch=epoch)
                # else:
                #     self.save_generated_seqs(self.test_X[:self.nb_to_generate],
                #                              max_vector=self.max_vector,
                #                              min_vector=self.min_vector,
                #                              suffix='original_input',epoch=epoch)

                # Reconstruct original sequences with decoder
                reconstruced_seqs, output_discriminator,output_classifier = self.autoencoder_with_discriminator.predict([self.test_X[:self.nb_to_generate],
                                                                                                   self.test_label_one_hot_code[:self.nb_to_generate]])

                self.save_generated_seqs(self.test_X[:self.nb_to_generate],
                                         max_vector=self.max_vector,
                                         min_vector=self.min_vector,
                                         suffix='original_input',epoch=epoch)

                # Reconstructed output sequences of the decoder
                self.save_generated_seqs(reconstruced_seqs, max_vector=self.max_vector,
                                         min_vector=self.min_vector,suffix='reconstructed', epoch=epoch)

                # Generate stylized sequences using the full model (the purpose of this model)
                for ll in range(self.nb_label):
                    ll_one_hot_code= self.convert_indices_2_onehot(np.asarray([ll] * (self.nb_to_generate/3)), nb_labels=self.nb_label)
                    random_generated_seqs = self.decoder.predict(x=[self.noise_vectors, ll_one_hot_code])
                    self.save_generated_seqs(random_generated_seqs,max_vector=self.max_vector,
                                             min_vector=self.min_vector, suffix='random_generated_label'+str(ll), epoch=epoch)

                # Record the loss at this current checkpoint, in a numpy array
                np.savez('loss_history.npz', self.loss_history)

            # Visualize weights averaged over each epoch, for each model sperately, if desired
            visualize_weights = False
            if visualize_weights == True:
                averaged_weights = []
                for a in self.autoencoder_with_discriminator.get_weights():
                    averaged_weights.append(a.mean())
                all_weights.append(averaged_weights)
            print '++++++++++++'
        print 'finished training..'

        # Visualize average weights, if desired
        if visualize_weights == True:
            # Create numpy matrix where columns to weights, and rows correspond to epochs
            all_weights = np.asarray(all_weights)
            plt.figure(figsize=(40, 80), dpi=200, facecolor='w', edgecolor='k')
            for i in range(1, all_weights.shape[1]+1):
                plt.subplot(all_weights.shape[1],1,i)
                plt.plot(all_weights[:,i-1])
                plt.title('Model: {}'.format(i))
                plt.ylabel('Average Weight')
                plt.xlabel('Epoch')

            plt.tight_layout()
            plt.savefig('./debugging/all_weights.png')
            plt.show()
            plt.close()

            plt.figure(figsize=(10, 10), dpi=300, facecolor='w', edgecolor='k')
            for i in range(1, all_weights.shape[1]+1):
                plt.plot(all_weights[:,i-1])
                plt.title('Model: {}'.format(i))
                plt.ylabel('Average Weight')
                plt.xlabel('Epoch')

                plt.tight_layout()
                plt.savefig('./debugging/{}_all_weights.png'.format(i))
                plt.show()
                plt.close()


        self.plot_loss()
        self.save_models()
        np.savez('loss_history.npz', self.loss_history)




    def plot_2d_histogram_latent_codes(self,latent_codes, bins=None, suffix=''):
        """
        Plots a 2 dimensional histogram of the latent space of the encoder.
        """

        if isinstance(latent_codes, list):
            latent_codes = np.asarray(latent_codes)
        if len(latent_codes.shape) ==3:
            latent_codes = latent_codes.reshape((latent_codes.shape[0] * latent_codes.shape[1],
                                                 latent_codes.shape[2]))

        dim_latent = latent_codes.shape[-1]
        nb_plots = dim_latent / 2
        if dim_latent % 2 == 1:
            nb_plots = nb_plots + 1
        cmap = matplotlib.cm.jet
        fig = plt.figure(figsize=(5, 4 * nb_plots))
        if bins is None:
            bins = np.arange(-5, 5, step=0.2)

        for i in range(nb_plots):
            plt.subplot(nb_plots, 1, i + 1)
            if i != nb_plots - 1:
                plt.hist2d(latent_codes[:, i * 2], latent_codes[:, i * 2 + 1], bins=bins, norm=LogNorm(), cmap=cmap)
            else:
                if i * 2 + 1 == dim_latent:
                    plt.hist2d(latent_codes[:, i * 2], latent_codes[:, i * 2 + 1], bins=bins, norm=LogNorm(), cmap=cmap)
                else:
                    plt.hist2d(latent_codes[:, i * 2 - 1], latent_codes[:, i * 2], bins=bins, norm=LogNorm(), cmap=cmap)
            plt.colorbar()

        plt.savefig('./hist2d_latent_dim' + suffix + '.png')
        plt.close(fig)


    def save_generated_seqs(self,seqs,max_vector,min_vector,suffix = '',epoch=None):
        """
        This saves the generated sequences, after performing some brief post
        processing, to .bvh files.
        """

        sequences = self.postprocess(seqs,max_vector,min_vector)  # Denormalize the scaled data back to euler angles scale (-90 to +90)
        for i, seq in enumerate(sequences):
            if epoch is None:
                filename = './generated_seq' + '_num_' + str(i) + suffix + '.bvh'
            else:
                filename = './generated_seq_epoch_' + str(epoch) + '_num_' + str(i) + suffix + '.bvh'
            save_seq_2_bvh(seq, sequence_name=filename, step=self.sampling_interval)


    def save_models(self,suffix=''):
        """
        At each specified check-point in our training, this function is used
        to save the weights of our model that is learned up to that point, which
        is helpful for reusing trained models.
        """

        self.autoencoder_with_discriminator.save_weights('autoencoder'+suffix+'.h5')
        with open('autoencoder'+suffix+'.yaml','w') as yaml_file:
            yaml_file.write(self.autoencoder_with_discriminator.to_yaml())
        yaml_file.close()

        self.encoder.save_weights('encoder'+suffix+'.h5')
        with open('encoder'+suffix+'.yaml','w') as yaml_file:
            yaml_file.write(self.encoder.to_yaml())
        yaml_file.close()

        self.decoder.save_weights('decoder'+suffix+'.h5')
        with open('decoder'+suffix+'.yaml','w') as yaml_file:
            yaml_file.write(self.decoder.to_yaml())
        yaml_file.close()

        self.discriminator.save_weights('discriminator'+suffix+'.h5')
        with open('discriminator'+suffix+'.yaml','w') as yaml_file:
            yaml_file.write(self.discriminator.to_yaml())
        yaml_file.close()

        self.classifier.save_weights('classifier' + suffix + '.h5')
        with open('classifier' + suffix + '.yaml', 'w') as yaml_file:
            yaml_file.write(self.classifier.to_yaml())
        yaml_file.close()


    def batch_generator(self,iterable1,iterable2,iterable3,batch_size=1,shuffle=False):
        l = len(iterable1)
        if shuffle ==True:
            indices = np.random.permutation(len(iterable1))
        else:
            indices = np.arange(0,stop=len(iterable1))
        for ndx in range(0,l,batch_size):
            cur_indices = indices[ndx:min(ndx+batch_size,l)]
            yield  iterable1[cur_indices],iterable2[cur_indices],iterable3[cur_indices]


    def training_loop(self,dataset,labels_one_hot_codes,positive_noise_set,batch_size):
        # Generate batch
        self.data_generator = self.batch_generator(dataset,labels_one_hot_codes,positive_noise_set,batch_size=batch_size)
        nb_batches = len(dataset)/batch_size +1
        for motion_batch,labels_batch,prior_noise_batch in self.data_generator:
            self.iterations = self.iterations +1
            if self.is_annealing_beta is True:
                new_beta_value = K.eval(K.sigmoid(self.beta_anneal_rate*
                                           self.iterations/(nb_batches+0.0)-
                                           self.bias_beta))

                K.set_value(self.beta_classifier, new_beta_value)
            cur_batch_size = len(motion_batch)

            # Create encodings
            latent_codes = self.encoder.predict(x=motion_batch,batch_size=cur_batch_size)
            X = np.concatenate((prior_noise_batch, latent_codes),axis=0)
            Y = [1.]*cur_batch_size+[0.]*cur_batch_size

            # Train discriminator and classifier on the encodings of the batch, if desired
            if self.train_disc ==True:
                self.discriminator.trainable=True
                self.discriminator.train_on_batch(x=X,y=Y)
            if self.train_classifier == True:
                self.classifier.trainable=True
                self.classifier.train_on_batch(x=latent_codes,y=labels_batch)
            self.classifier.trainable = False
            self.discriminator.trainable = False
            Y_hat = np.asarray([1.]*cur_batch_size,dtype=np.float32)
            self.autoencoder_with_discriminator.train_on_batch(x=[motion_batch,labels_batch],y={'Decoder':motion_batch,\
                                                    'Discmt':Y_hat,'Classifier':Y_hat})

if __name__ == "__main__":
    import sys
    import os

    root_path = os.getcwd()[:-15]  # Gets the path above the root directory
    sys.path.append(root_path)
    from Seq_AAE_V1.datasets.dataset import Emilya_Dataset
    from Seq_AAE_V1.datasets.dataset import Emilya_Dataset

    dataset_obj = Emilya_Dataset(window_width=200,shift_step=20,
                                 sampling_interval=None,
                                 with_velocity=False,
                                 number=200,nb_valid=200,nb_test=200)
    model = Double_GAN_Conditional_SAAE(forget_bias=True,  # Added this to improve stability and avoid vanishing gradient
                                    latent_dim=50,latent_activation='tanh',latent_BN=False,
                                    hidden_dim_enc_list=[100,100],activation_enc_list=['tanh','tanh'],
                                    hidden_dim_dec_list=[100,100],activation_dec_list=['tanh','tanh'],
                                    hidden_dim_dis_list=[100,40],activation_dis_list=['relu','relu'],
                                    dropout_dis_list=[0.0,0.0],batch_size=20,max_epoch=100,
                                    optimiser_autoencoder='rmsprop',optimiser_dis='sgd',
                                    lr_autoencoder=0.001,lr_dis=0.01,decay_autoencoder=0.0,decay_dis=0.0,
                                    momentum_autoencoder=0.0,momentum_dis=0.0,
                                    prior_noise_type='Gaussian',
                                    loss_weights=[1.0,0.001,0.001],
                                    train_disc=True,
                                    train_classifier=True,
                                    custom_loss=True,symetric_autoencoder=False,
                                    nb_to_generate=10,
                                    condition_activity_or_emotion=1,
                                    nb_label=8,fully_condition=False,
                                    is_annealing_beta=True,
                                    beta_anneal_rate=0.1,
                                    bias_beta=9.)
    model.training(dataset_obj)
